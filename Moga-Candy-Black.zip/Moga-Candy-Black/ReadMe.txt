Moga Candy Black (vr 1.0) for Linux.

Created by MOYASH.
------------------

to install: 

1-Move "Moga-Candy-Black" folder to the ".icons" folder in your "Home" directory.

2-Then Choose and Apply the Cursor Name.
---------------------------------------

License:(CC BY-NC-ND).
---------------------

Support Creator: ($3.0 or more)

***** Buy a Coffee for MOYASH *****
ko-fi.com/moyash
buymeacoffee.com/moyash


***** Direct Donation via PayPal *****
paypal.me/MOYASH77
----------------------------------------------------------

Thanks for Downloading my Work.
Copyright 2025 Moyash, All right reserved.
-----------------------------------------------------